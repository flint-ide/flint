# @wunderui/react — WunderUI Free

The free components of [WunderUI](https://wunderui.com), a design system and React component library built on
[Base UI](https://base-ui.com) and Tailwind CSS v4: 89 components (buttons, inputs, selects,
dialogs, tables, tabs, calendar, date picker and more) with a matching Figma library, all driven by one
set of design tokens, light and dark. MIT licence.

This package contains the **Free** components only. WunderUI **Core** and **Pro** (charts, data tables,
AI and agent components, UI blocks and templates) come with a plan on [wunderui.com](https://wunderui.com/#pricing)
and are not part of this package.

- Docs & live examples: https://wunderui.com/components
- Source of the free components: https://github.com/wunder-ui/wunderui

## Install

```bash
npm install @wunderui/react
```

Peer dependencies: `react` / `react-dom` 19 and `tailwindcss` 4.

## Styles

Import the tokens after your Tailwind entry point and let Tailwind scan the package's compiled
output for the utility classes the components use:

```css
/* app/globals.css */
@import "tailwindcss";
@import "@wunderui/react/styles.css";
@source "../node_modules/@wunderui/react/dist";
```

`styles.css` defines the light and dark token sets. Dark mode is class-based: add `class="dark"` to
`<html>` or use the exported `ThemeProvider` (wraps `next-themes`).

## Use

```tsx
import { Button, Card, CardHeader, CardTitle, Badge } from "@wunderui/react"

export function Example() {
  return (
    <Card className="w-80">
      <CardHeader>
        <CardTitle>Invoices</CardTitle>
        <Badge color="green">Paid</Badge>
      </CardHeader>
      <Button variant="primary">Download</Button>
    </Card>
  )
}
```

All components are client components (`"use client"` is baked into the build) and work in Next.js
App Router, Vite, Remix and any other React 19.3+ setup.

## For AI agents

`design.json` (in this package) lists every free component with its exports, props and an example;
`figma-map.json` maps the Figma component sets to the React components.

## License

MIT — see `LICENSE`. WunderUI Core and Pro, the UI blocks, templates and the full Figma library are a
separate, paid product (https://wunderui.com/#pricing) and are not part of this package.
